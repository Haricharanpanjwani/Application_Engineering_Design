use DBProject

select * from Earthquake

delete from Earthquake where locationID = 3

insert into earthquake values (5,3, GETDATE(), 7, 120, 37);